package com.appsdeveloperblog.photoapp.orders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersResourceServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
