package com.appsdeveloperblog.photoapp.orders;

public enum OrderStatus {
 NEW, APPROVED, REJECTED
}
