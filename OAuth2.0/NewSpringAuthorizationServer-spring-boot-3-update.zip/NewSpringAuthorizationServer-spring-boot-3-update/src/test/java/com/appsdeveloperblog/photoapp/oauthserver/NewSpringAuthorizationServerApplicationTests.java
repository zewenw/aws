package com.appsdeveloperblog.photoapp.oauthserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewSpringAuthorizationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
